package com.scoreguard.ht;

import org.junit.Test;
import static org.junit.Assert.*;

public class MatchImageParserTest {
    @Test public void parsesProvidedScreenshotExactly(){
        MatchImageParser m=MatchImageParser.parse("2026-11-14 15:30 开赛\nVilla Dalmine vs Deportivo Camioneros\nFixture ID: 1648801");
        assertEquals(1648801,m.fixtureId);
        assertEquals("2026-11-14",m.date);
        assertEquals("15:30",m.time);
        assertEquals("Villa Dalmine",m.home);
        assertEquals("Deportivo Camioneros",m.away);
    }
    @Test public void handlesOcrIdOneConfusion(){
        MatchImageParser m=MatchImageParser.parse("Fixture 1D: 1648801\nVilla Dalmine vs Deportivo Camioneros");
        assertEquals(1648801,m.fixtureId);
    }
    @Test public void rejectsWrongFixtureCandidate(){
        MatchImageParser m=MatchImageParser.parse("Villa Dalmine vs Deportivo Camioneros\nFixture ID: 1648801");
        Models.Fixture wrong=new Models.Fixture();wrong.home="Renate";wrong.away="Desenzano Calvina";
        assertFalse(m.teamsMatch(wrong));
    }
    @Test public void handlesDiacriticsWithoutInventingId(){
        MatchImageParser m=MatchImageParser.parse("Villa Dálmine vs Deportivo Camioneros");
        assertEquals(-1,m.fixtureId);
        assertTrue(MatchImageParser.sameTeam(m.home,"Villa Dalmine"));
    }
    @Test public void cannotConfuseDateNumbersWithFixtureId(){
        MatchImageParser m=MatchImageParser.parse("2026-11-14 15:30 开赛");
        assertEquals(-1,m.fixtureId);
        assertFalse(m.useful());
    }
}
