package com.scoreguard.ht;

import org.junit.Test;
import static org.junit.Assert.*;

public class RiskEngineTest {
    private static final long NOW=1_700_000_000_000L;
    private Models.Snapshot sample(int minute,int hshots,int ashots,int hbox,int abox,int hon,int aon,long time){
        Models.Snapshot s=new Models.Snapshot();s.fixture.minute=minute;s.fixture.status="1H";
        s.fixture.homeScore=1;s.fixture.awayScore=0;s.fetchedAt=time;
        s.home.totalShots=hshots;s.away.totalShots=ashots;
        s.home.shotsInsideBox=hbox;s.away.shotsInsideBox=abox;
        s.home.shotsOnGoal=hon;s.away.shotsOnGoal=aon;
        s.home.corners=1;s.away.corners=0;
        return s;
    }
    private Models.Portfolio portfolio(String primary,String insurance){
        Models.Portfolio p=new Models.Portfolio();
        Models.Bet a=new Models.Bet("主单");a.score=primary;
        Models.Bet b=new Models.Bet("保险单1");b.score=insurance;
        p.bets.add(a);p.bets.add(b);return p;
    }
    @Test public void scoreOnlyTwoOrThreeBets(){
        Models.Fixture f=new Models.Fixture();f.homeScore=1;f.awayScore=0;
        Models.Portfolio p=portfolio("1-0","0-0");
        assertTrue(p.matched(f));assertEquals(2,p.bets.size());
        Models.Bet c=new Models.Bet("保险单2");c.score="2-0";
        p.bets.add(c);assertEquals(3,p.bets.size());
    }
    @Test public void absentSnapshotsNeverInventTrend(){
        Models.Snapshot s=sample(25,-1,-1,-1,-1,-1,-1,NOW);
        RiskEngine.Result r=RiskEngine.evaluate(s,null,null,portfolio("1-0","2-0"));
        assertTrue(r.message.contains("暂无可比较的历史快照"));
        assertTrue(r.homeTrend.contains("缺少"));
        assertTrue(r.awaySignal.contains("数据不足"));
        assertFalse(r.message.contains("本金"));
    }
    @Test public void independentTeamSignalsAndRisingMomentum(){
        Models.Snapshot at15=sample(15,1,2,0,1,0,1,NOW-10*60_000L);
        Models.Snapshot at20=sample(20,2,3,1,2,1,1,NOW-5*60_000L);
        Models.Snapshot at25=sample(25,7,3,4,2,3,1,NOW);
        RiskEngine.Result r=RiskEngine.evaluate(at25,at20,at15,portfolio("1-0","2-0"));
        assertTrue(r.homeSignal.contains("明显"));
        assertTrue(r.awaySignal.contains("低活动"));
        assertTrue(r.homeTrend.contains("增强"));
        assertTrue(r.message.contains("主队再进一球"));
        assertTrue(r.message.contains("客队再进一球"));
        assertTrue(r.label.contains("警戒"));
    }
    @Test public void ifNeitherSideShootsQuietIsNotSafety(){
        Models.Snapshot at20=sample(20,2,2,1,1,1,1,NOW-5*60_000L);
        Models.Snapshot at25=sample(25,2,2,1,1,1,1,NOW);
        RiskEngine.Result r=RiskEngine.evaluate(at25,at20,null,portfolio("1-0","2-0"));
        assertTrue(r.label.contains("低射门活动"));
        assertTrue(r.homeSignal.contains("不代表无进球风险"));
    }
    @Test public void targetChangedNeedsNewReview(){
        Models.Snapshot at20=sample(20,2,2,1,1,1,1,NOW-5*60_000L);
        Models.Snapshot at25=sample(25,5,2,3,1,2,1,NOW);
        at25.fixture.homeScore=2;
        RiskEngine.Result r=RiskEngine.evaluate(at25,at20,null,portfolio("1-0","2-0"));
        assertTrue(r.targetMatched);
        assertTrue(r.label.contains("重新评估"));
    }
    @Test public void historicalSnapshotTooStaleMustNotCount(){
        Models.Snapshot old=sample(20,2,2,1,1,1,1,NOW-40*60_000L);
        Models.Snapshot now=sample(25,5,2,3,1,2,1,NOW);
        RiskEngine.Result r=RiskEngine.evaluate(now,old,null,portfolio("1-0","2-0"));
        assertTrue(r.homeSignal.contains("数据不足"));
    }
}
