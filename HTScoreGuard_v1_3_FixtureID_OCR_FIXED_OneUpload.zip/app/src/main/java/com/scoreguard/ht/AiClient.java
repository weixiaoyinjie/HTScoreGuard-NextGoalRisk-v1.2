package com.scoreguard.ht;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.Set;

final class AiClient {
    private AiClient() { }
    static String analyze(String apiKey,String model,Models.Snapshot now,Models.Snapshot old,Models.Snapshot before,
                          Models.Portfolio portfolio,TeamResearch research,String localReport,boolean allowWeb) throws Exception {
        if(apiKey==null||apiKey.trim().isEmpty())return "AI API未配置，已展示本地规则分析。";
        try{return request(apiKey,model,now,old,before,portfolio,research,localReport,allowWeb);}
        catch(Exception e){
            if(!allowWeb)throw e;
            return "【联网研究不可用，已改为只分析足球API资料】\n联网失败原因："+e.getMessage()+"\n\n"
                    +request(apiKey,model,now,old,before,portfolio,research,localReport,false);
        }
    }
    private static String request(String apiKey,String model,Models.Snapshot now,Models.Snapshot old,Models.Snapshot before,
                                  Models.Portfolio portfolio,TeamResearch research,String localReport,boolean allowWeb) throws Exception {
        JSONObject payload=new JSONObject();
        payload.put("model",model==null||model.trim().isEmpty()?"gpt-4.1-mini":model.trim());
        payload.put("store",false);
        if(allowWeb){
            JSONArray tools=new JSONArray();tools.put(new JSONObject().put("type","web_search").put("search_context_size","low"));
            payload.put("tools",tools);payload.put("tool_choice","auto");
        }
        payload.put("instructions","你是足球上半场目标比分维持风险研究员，回答必须使用中文。"
                +"你只能基于提供的比赛快照、API赛前历史和实际可验证的网页来源分析。"
                +"必须分别评估主队下一球和客队下一球，以及两方最近3-10分钟的风险变化；只分析当前目标比分是否容易被改写，不讨论赔率、金额、下注比例。"
                +"主动检查联赛级别、双方最近8-10场的全场与半场进球、主客分化、是否有高比分倾向、早进球倾向。"
                +"只有明确的分钟事件数据才能论证0-15分钟早进球，不允许由半场比分推断进球时间。"
                +"历史比赛请注明样本量、赛事混合、赛季、比赛日和资料查询时间；资料不完整的低级别联赛必须降低置信度。"
                +"现在的实时API数据比历史印象更重要。不要把全场进球率当成上半场进球率，不要把控球和角球当成真正射门质量。"
                +"两个快照之间的累计差值不是逐次射门质量；没有足够采样时明确写趋势未知，不得把沉闷等同于安全。"
                +"AI联网检索时只能使用可靠、明确和最新的页面，不要编造文献、比分、xG、伤停或链接；每项外部结论必须给出日期和URL。"
                +"若没有检索结果写明网页资料无法核实。不能使用本场未来事件，不能给未经校准的精确进球概率。"
                +"按照7段输出：①现在比赛与目标比分；②最近5-10分钟真实变化；③主队下一球可能的证据；"
                +"④客队下一球可能的证据；⑤两队近况与赛事进球特征（注明来源和样本量）；"
                +"⑥数据缺陷及最大风险；⑦继续持有条件与结算前的人工核对清单，评级C/PASS或谨慎观察。"
                +"你只能提供参考，不能代用户结算或投注。");
        JSONObject evidence=new JSONObject();
        evidence.put("fixture_id",now.fixture.id).put("home_team",now.fixture.home)
                .put("away_team",now.fixture.away).put("league",now.fixture.league)
                .put("score",now.fixture.score()).put("minute",now.fixture.minute)
                .put("status",now.fixture.status).put("captured_at_ms",now.fetchedAt)
                .put("now",now.json()).put("previous_snapshot",old==null?JSONObject.NULL:old.json())
                .put("previous_previous_snapshot",before==null?JSONObject.NULL:before.json())
                .put("user_score_targets",portfolio.json()).put("events",now.events)
                .put("last_goal_minute",now.lastGoalMinute)
                .put("historical_football_api_research",research==null?JSONObject.NULL:research.json())
                .put("local_evidence_report",localReport)
                .put("live_xg","not available from this provider");
        String preface=allowWeb?"请联网核查两队比赛前的背景和近况，列出实际检索到的来源URLs。如资料无法验证不要填充。\n":"本次不使用联网检索，请只分析结构化足球API资料。\n";
        payload.put("input",preface+evidence.toString());
        HttpURLConnection c=(HttpURLConnection)new URL("https://api.openai.com/v1/responses").openConnection();
        try {
            c.setRequestMethod("POST");c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json; charset=utf-8");
            c.setRequestProperty("Authorization","Bearer "+apiKey.trim());
            c.setConnectTimeout(12000);c.setReadTimeout(75000);
            try(OutputStream out=c.getOutputStream()){
                out.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code=c.getResponseCode();InputStream stream=code>=400?c.getErrorStream():c.getInputStream();
            if(stream==null)throw new IllegalStateException("AI API HTTP "+code);
            String content;
            try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buf=new byte[4096];int n;
                while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>4_000_000)throw new IllegalStateException("AI响应太大");}
                content=out.toString(StandardCharsets.UTF_8.name());
            }
            if(code>=400)throw new IllegalStateException("AI API HTTP "+code+": "+content.substring(0,Math.min(250,content.length())));
            JSONObject result=new JSONObject(content);StringBuilder answer=new StringBuilder();Set<String> urls=new LinkedHashSet<>();
            JSONArray output=result.optJSONArray("output");
            if(output!=null)for(int i=0;i<output.length();i++){
                JSONObject item=output.optJSONObject(i);if(item==null||!"message".equals(item.optString("type")))continue;
                JSONArray texts=item.optJSONArray("content");if(texts==null)continue;
                for(int j=0;j<texts.length();j++){
                    JSONObject piece=texts.optJSONObject(j);if(piece==null)continue;
                    if("output_text".equals(piece.optString("type")))answer.append(piece.optString("text")).append("\n");
                    JSONArray annotations=piece.optJSONArray("annotations");
                    if(annotations!=null)for(int k=0;k<annotations.length();k++){
                        JSONObject a=annotations.optJSONObject(k);
                        if(a!=null&&"url_citation".equals(a.optString("type"))){
                            String url=a.optString("url","");if(url.startsWith("https://"))urls.add(url);
                        }
                    }
                }
            }
            if(answer.length()==0)throw new IllegalStateException("AI响应不含正文，状态："+result.optString("status","unknown"));
            if(!urls.isEmpty()){
                answer.append("\n【网页来源链接（请人工核对）】\n");
                for(String url:urls)answer.append(url).append("\n");
            }
            if(allowWeb&&urls.isEmpty())answer.append("\n注意：未提取到可验证的网页来源链接，网页资料须人工复核。\n");
            return answer.toString();
        }finally{c.disconnect();}
    }
}
