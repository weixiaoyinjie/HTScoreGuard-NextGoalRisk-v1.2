package com.scoreguard.ht;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Explainable, non-calibrated activity signal for each side, NOT a goal probability. */
public final class RiskEngine {
    private RiskEngine() { }
    public static final class Result {
        public String label="数据不足", message="", momentum="数据不足";
        public String homeSignal="无法评估",awaySignal="无法评估";
        public String homeTrend="变化未知",awayTrend="变化未知";
        public String homeDetail="",awayDetail="";
        public boolean targetMatched=false;
        public int signals=0;
    }
    private static final class Delta {
        int shots=-1,box=-1,on=-1,corners=-1,minutes=-1;
        boolean usable(){return minutes>=3 && minutes<=10 && shots>=0 && box>=0 && on>=0;}
        int activity(){return box*2+on*2+shots/2;} // Heuristic; not calibrated
        boolean quiet(){return usable()&&shots==0&&box==0&&on==0;}
        boolean active(){return usable()&&(box>=2||on>=2||shots>=4);}
        boolean moderate(){return usable()&&(box>=1||on>=1||shots>=2);}
    }
    private static int diff(int a,int b){return a<0||b<0||a<b?-1:a-b;}
    private static String n(int x){return x<0?"缺失":String.valueOf(x);}
    private static String pp(int a,int b){return n(a)+" / "+n(b);}
    private static String dd(int x){return x<0?"缺失/修正":"+"+x;}
    private static Delta calc(Models.Stat current,Models.Stat previous,int minutes){
        Delta r=new Delta();r.minutes=minutes;
        r.shots=diff(current.totalShots,previous.totalShots);
        r.box=diff(current.shotsInsideBox,previous.shotsInsideBox);
        r.on=diff(current.shotsOnGoal,previous.shotsOnGoal);
        r.corners=diff(current.corners,previous.corners);
        return r;
    }
    private static boolean comparable(Models.Snapshot now,Models.Snapshot earlier){
        if(now==null||earlier==null||!"1H".equals(now.fixture.status)||!"1H".equals(earlier.fixture.status))return false;
        int gap=now.fixture.minute-earlier.fixture.minute;
        if(gap<3||gap>10||now.fetchedAt<=earlier.fetchedAt)return false;
        // A stale cache or a reverted match clock must not be used as a real-time trend.
        long wall=now.fetchedAt-earlier.fetchedAt;
        return wall>0&&wall<20*60_000L;
    }
    private static String signal(Delta d){
        if(!d.usable())return "数据不足（不能断言安全）";
        if(d.active())return "近期攻击活动明显（重点警戒）";
        if(d.moderate())return "近期存在进攻活动（继续观察）";
        if(d.quiet())return "近期射门低活动（不代表无进球风险）";
        return "近期射门活动较少（继续观察）";
    }
    private static String trend(Delta latest,Delta preceding){
        if(!latest.usable()||!preceding.usable())return "缺少前一窗口，无法比较趋势";
        // Compare like-for-like rates per minute; +/- 20% differences are not proof of change.
        int newer=latest.activity()*preceding.minutes;
        int older=preceding.activity()*latest.minutes;
        if(newer>=older+Math.max(4,latest.minutes))return "增强 ↑";
        if(older>=newer+Math.max(4,latest.minutes))return "衰减 ↓";
        return "未见明确增强或衰减 →";
    }
    private static String describe(Delta d,String trend){
        if(!d.usable())return "最近3～10分钟的射门/射正/禁区射门差值不齐，不能评估进攻变化。";
        return "近"+d.minutes+"分钟：射门"+dd(d.shots)+"、射正"+dd(d.on)
                +"、禁区内射门"+dd(d.box)+"、角球"+dd(d.corners)+"；趋势："+trend+"。";
    }
    private static boolean changedScore(Models.Snapshot now,Models.Snapshot prev){
        return prev!=null && prev.fixture.homeScore>=0&&prev.fixture.awayScore>=0
                &&(now.fixture.homeScore!=prev.fixture.homeScore||now.fixture.awayScore!=prev.fixture.awayScore);
    }
    public static Result evaluate(Models.Snapshot now,Models.Snapshot prev,Models.Portfolio bets){
        return evaluate(now,prev,null,bets);
    }
    /** Latest, earlier (~5min) and prior (~10min) snapshots must be actual observations of this fixture. */
    public static Result evaluate(Models.Snapshot now,Models.Snapshot prev,Models.Snapshot before,
                                  Models.Portfolio bets){
        Result out=new Result();Models.Fixture f=now.fixture;
        boolean matched=bets!=null&&bets.matched(f);out.targetMatched=matched;
        boolean currentWindow=comparable(now,prev);
        boolean priorWindow=currentWindow&&comparable(prev,before);
        Delta hd=currentWindow?calc(now.home,prev.home,f.minute-prev.fixture.minute):new Delta();
        Delta ad=currentWindow?calc(now.away,prev.away,f.minute-prev.fixture.minute):new Delta();
        Delta h0=priorWindow?calc(prev.home,before.home,prev.fixture.minute-before.fixture.minute):new Delta();
        Delta a0=priorWindow?calc(prev.away,before.away,prev.fixture.minute-before.fixture.minute):new Delta();
        out.homeSignal=signal(hd);out.awaySignal=signal(ad);
        out.homeTrend=trend(hd,h0);out.awayTrend=trend(ad,a0);
        out.homeDetail=describe(hd,out.homeTrend);out.awayDetail=describe(ad,out.awayTrend);
        boolean hasData=hd.usable()&&ad.usable();
        boolean changed=changedScore(now,prev);
        boolean red=(now.home.red>0||now.away.red>0||now.events.toLowerCase(Locale.ROOT).contains("red card"));
        boolean recentGoal=now.lastGoalMinute>=0&&f.minute>=now.lastGoalMinute&&f.minute-now.lastGoalMinute<=5;
        boolean higherActivity=hasData&&(hd.active()||ad.active());
        boolean quiet=hasData&&hd.quiet()&&ad.quiet()&&!changed&&!red&&!recentGoal;
        out.signals=(hd.active()?1:0)+(ad.active()?1:0)+(red?1:0)+(changed?1:0);
        if(!"1H".equals(f.status))out.label="非上半场直播 / PASS";
        else if(!matched)out.label="未达到任何目标比分 / 观察";
        else if(changed||red)out.label="比分/红牌改变：重新评估";
        else if(!hasData)out.label="PASS / 双方近期数据不足";
        else if(higherActivity)out.label="下一球警戒：考虑人工评估结算";
        else if(quiet)out.label="双方低射门活动：可继续观察";
        else out.label="C级：持续观察，不能认定安全";
        out.momentum="主队："+out.homeTrend+"；客队："+out.awayTrend;

        StringBuilder sb=new StringBuilder();
        sb.append("【比赛与比分目标】\n").append(f.liveDisplay())
          .append("\n比赛ID：").append(f.id)
          .append("；抓取时间：").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault())
                   .format(new Date(now.fetchedAt))).append("\n");
        if(bets!=null)for(Models.Bet b:bets.bets)sb.append(b.label).append(" ").append(b.score)
                .append(b.targetNow(f)?" ● 当前目标已出现":" ○ 当前未匹配").append("\n");
        sb.append("当前是否匹配任一目标：").append(matched?"是":"否")
          .append("。只提供比分保持和下一球方向的参考。\n");
        sb.append("最近一粒已记录进球：").append(now.lastGoalMinute>=0?now.lastGoalMinute+"分钟":"时间缺失")
          .append("；上半场补时并不固定为45分钟。\n\n");
        sb.append("【双方下一球风险追踪】\n")
          .append("主队再进一球：").append(out.homeSignal).append("\n").append(out.homeDetail).append("\n")
          .append("客队再进一球：").append(out.awaySignal).append("\n").append(out.awayDetail).append("\n");
        if(recentGoal)sb.append("距离最近进球不超过5比赛分钟：节奏可能重新变化；不要把进球前形势直接沿用。\n");
        if(changed)sb.append("两次快照之间比分已变，前次对目标比分的判断失效，需重新评估。\n");
        if(red)sb.append("出现红牌信号：攻守结构可能发生突变，需核对事件详情。\n");
        sb.append("\n【累计统计（主队 / 客队）】\n")
          .append("射门 ").append(pp(now.home.totalShots,now.away.totalShots)).append("；射正 ").append(pp(now.home.shotsOnGoal,now.away.shotsOnGoal)).append("\n")
          .append("禁区内射门 ").append(pp(now.home.shotsInsideBox,now.away.shotsInsideBox)).append("；禁区外射门 ")
          .append(pp(now.home.shotsOutsideBox,now.away.shotsOutsideBox)).append("\n")
          .append("射偏 ").append(pp(now.home.shotsOffGoal,now.away.shotsOffGoal)).append("；被封堵 ")
          .append(pp(now.home.blockedShots,now.away.blockedShots)).append("\n")
          .append("角球 ").append(pp(now.home.corners,now.away.corners)).append("；控球% ")
          .append(pp(now.home.possession,now.away.possession)).append("\n")
          .append("红牌 ").append(pp(now.home.red,now.away.red)).append("；黄牌 ")
          .append(pp(now.home.yellow,now.away.yellow)).append("\n")
          .append("注意：当前提供商没有逐次射门xG、禁区触球或连续进攻动量数据，显示缺失，不模拟成官方数据。\n\n");
        if(currentWindow){
            sb.append("【本机真实采样窗口】").append(prev.fixture.minute).append("'→").append(f.minute)
              .append("'（按累计值作差，并非官方逐分钟明细）\n")
              .append("最近前一窗口：").append(priorWindow?before.fixture.minute+"'→"+prev.fixture.minute+"'":"尚无合适记录")
              .append("；若统计发生修正，趋势标记为不可用。\n\n");
        }else sb.append("【最近5～10分钟】\n暂无可比较的历史快照，不能重建首次打开App前的射门变化。请保持前台采样。\n\n");
        sb.append("【人工参考结论】").append(out.label).append("\n");
        if(matched&&quiet)sb.append("双方当前观察窗口的射门较少，可继续观察，但不能证明比分会维持。\n");
        if(matched&&higherActivity)sb.append("至少一队近期有明显攻击活动；必须检查是哪一方威胁你的目标比分，以及真实射门质量。\n");
        sb.append("【事件列表】\n").append(now.events.isEmpty()?"API暂未取得进球/红牌等事件\n":now.events)
          .append("\n【数据纪律】本地阈值尚未回测与概率校准；方向信号不是胜率，亦不能替代比赛视频或真实xG。")
          .append("不操作投注平台，不自动结算。\n");
        out.message=sb.toString();return out;
    }
}
