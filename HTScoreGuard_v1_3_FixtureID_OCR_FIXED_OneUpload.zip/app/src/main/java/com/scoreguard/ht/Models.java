package com.scoreguard.ht;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public final class Models {
    private Models() { }

    public static final class Stat {
        public int shotsOnGoal=-1, shotsOffGoal=-1, totalShots=-1, shotsInsideBox=-1,
                shotsOutsideBox=-1, blockedShots=-1, corners=-1, yellow=-1, red=-1,
                possession=-1, fouls=-1, saves=-1;

        public int get(String type) {
            switch(type) {
                case "Shots on Goal": return shotsOnGoal;
                case "Shots off Goal": return shotsOffGoal;
                case "Total Shots": return totalShots;
                case "Shots insidebox": return shotsInsideBox;
                case "Shots outsidebox": return shotsOutsideBox;
                case "Blocked Shots": return blockedShots;
                case "Corner Kicks": return corners;
                case "Yellow Cards": return yellow;
                case "Red Cards": return red;
                case "Ball Possession": return possession;
                case "Fouls": return fouls;
                case "Goalkeeper Saves": return saves;
                default: return -1;
            }
        }

        public void set(String type, int value) {
            switch(type) {
                case "Shots on Goal": shotsOnGoal=value; break;
                case "Shots off Goal": shotsOffGoal=value; break;
                case "Total Shots": totalShots=value; break;
                case "Shots insidebox": shotsInsideBox=value; break;
                case "Shots outsidebox": shotsOutsideBox=value; break;
                case "Blocked Shots": blockedShots=value; break;
                case "Corner Kicks": corners=value; break;
                case "Yellow Cards": yellow=value; break;
                case "Red Cards": red=value; break;
                case "Ball Possession": possession=value; break;
                case "Fouls": fouls=value; break;
                case "Goalkeeper Saves": saves=value; break;
            }
        }

        public JSONObject json() {
            JSONObject j=new JSONObject();
            try { for (String key: FootballApi.STAT_TYPES) j.put(key,get(key)); } catch(Exception ignored) { }
            return j;
        }
        public static Stat fromJson(JSONObject j) {
            Stat s=new Stat(); if(j==null) return s;
            for(String key: FootballApi.STAT_TYPES) s.set(key,j.optInt(key,-1));
            return s;
        }
    }

    public static final class Fixture {
        public int id=-1, minute=-1, homeScore=-1, awayScore=-1, homeId=-1, awayId=-1, leagueId=-1, season=-1;
        public String home="", away="", league="", date="", status="";

        public String display() { return home+" vs "+away+"  ["+league+"]  "+date; }
        public String liveDisplay() {
            return home+" "+score()+" "+away+" · "+(minute<0?"时间未知":minute+"'")+" · "+status;
        }
        public String score() { return homeScore<0||awayScore<0 ? "?-?" : homeScore+"-"+awayScore; }
    }

    public static final class Snapshot {
        public Fixture fixture=new Fixture();
        public Stat home=new Stat(), away=new Stat();
        public long fetchedAt=System.currentTimeMillis();
        public String events="";
        public int lastGoalMinute=-1;
        public boolean isLiveFirstHalf() { return "1H".equals(fixture.status); }
        public JSONObject json() {
            JSONObject j=new JSONObject();
            try {
                j.put("minute",fixture.minute).put("homeScore",fixture.homeScore)
                 .put("awayScore",fixture.awayScore).put("fetchedAt",fetchedAt)
                 .put("home",home.json()).put("away",away.json()).put("status",fixture.status)
                 .put("lastGoalMinute",lastGoalMinute);
            } catch(Exception ignored) { }
            return j;
        }
        public static Snapshot fromJson(JSONObject j) {
            Snapshot s=new Snapshot(); s.fixture.minute=j.optInt("minute",-1);
            s.fixture.homeScore=j.optInt("homeScore",-1); s.fixture.awayScore=j.optInt("awayScore",-1);
            s.fixture.status=j.optString("status",""); s.fetchedAt=j.optLong("fetchedAt",0);
            s.lastGoalMinute=j.optInt("lastGoalMinute",-1);
            s.home=Stat.fromJson(j.optJSONObject("home")); s.away=Stat.fromJson(j.optJSONObject("away"));
            return s;
        }
    }

    public static final class Bet {
        public String label, score="";
        public Bet(String label){this.label=label;}
        public boolean targetNow(Fixture f){return score.trim().equals(f.score());}
        public JSONObject json(){
            JSONObject j=new JSONObject();
            try {j.put("label",label).put("score",score);} catch(Exception ignored){}
            return j;
        }
        public static Bet fromJson(JSONObject j){
            Bet b=new Bet(j.optString("label","保险单"));b.score=j.optString("score","");return b;
        }
    }
    public static final class Portfolio {
        public final List<Bet> bets=new ArrayList<>();
        public boolean matched(Fixture f){for(Bet b:bets)if(b.targetNow(f))return true;return false;}
        public JSONArray json(){JSONArray a=new JSONArray();for(Bet b:bets)a.put(b.json());return a;}
        public static Portfolio fromJson(JSONArray a){Portfolio p=new Portfolio();
            if(a!=null)for(int i=0;i<a.length();i++){
                JSONObject v=a.optJSONObject(i);if(v!=null)p.bets.add(Bet.fromJson(v));
            }
            return p;
        }
    }
}
