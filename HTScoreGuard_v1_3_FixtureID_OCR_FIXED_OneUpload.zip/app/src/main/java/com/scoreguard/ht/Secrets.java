package com.scoreguard.ht;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Locally encrypts keys with Android Keystore. Never writes plaintext keys to preferences. */
final class Secrets {
    private static final String ALIAS="ht_scoreguard_local_key_v1";
    private static final String STORE="scoreguard_secrets";
    private static SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        KeyStore.SecretKeyEntry entry=(KeyStore.SecretKeyEntry)ks.getEntry(ALIAS,null);
        if(entry!=null)return entry.getSecretKey();
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return generator.generateKey();
    }
    static void put(Context ctx,String name,String value) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] data=cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        byte[] iv=cipher.getIV();byte[] joined=new byte[iv.length+data.length];
        System.arraycopy(iv,0,joined,0,iv.length);System.arraycopy(data,0,joined,iv.length,data.length);
        ctx.getSharedPreferences(STORE,Context.MODE_PRIVATE).edit()
                .putString(name,Base64.encodeToString(joined,Base64.NO_WRAP)).apply();
    }
    static String get(Context ctx,String name) {
        try {
            SharedPreferences p=ctx.getSharedPreferences(STORE,Context.MODE_PRIVATE);
            String encoded=p.getString(name,"");if(encoded.isEmpty())return "";
            byte[] bytes=Base64.decode(encoded,Base64.NO_WRAP);
            if(bytes.length<28)return "";
            byte[] iv=new byte[12],data=new byte[bytes.length-12];
            System.arraycopy(bytes,0,iv,0,12);System.arraycopy(bytes,12,data,0,data.length);
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
            return new String(c.doFinal(data),StandardCharsets.UTF_8);
        }catch(Exception ignored){return "";}
    }
}
