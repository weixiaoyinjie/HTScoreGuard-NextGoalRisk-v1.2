package com.scoreguard.ht;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.LinkedHashSet;
import java.util.Set;

/** Reproducible pre-match facts fetched from completed historical games only. */
public final class TeamResearch {
    public int fixtureId,leagueId,season;
    public String homeTeam="",awayTeam="",league="",fixtureStatsCoverage="未知",coverageWarning="";
    public long fetchedAt;
    public final Form home=new Form(),away=new Form();

    public static final class Game {
        int fixtureId,homeGoals=-1,awayGoals=-1,htHome=-1,htAway=-1;
        String home="",away="",league="",date="";
        boolean atHome;
        JSONObject json(){JSONObject j=new JSONObject();try{
            j.put("fixtureId",fixtureId).put("date",date).put("league",league)
             .put("home",home).put("away",away).put("fulltime",homeGoals+"-"+awayGoals)
             .put("halftime",htHome<0||htAway<0?JSONObject.NULL:htHome+"-"+htAway)
             .put("atHome",atHome);
        }catch(Exception ignored){}return j;}
        static Game fromJson(JSONObject j){Game g=new Game();g.fixtureId=j.optInt("fixtureId",-1);
            g.date=j.optString("date","");g.league=j.optString("league","");
            g.home=j.optString("home","");g.away=j.optString("away","");
            g.atHome=j.optBoolean("atHome",false);
            String[] ft=j.optString("fulltime","").split("-");String[] ht=j.optString("halftime","").split("-");
            try{g.homeGoals=Integer.parseInt(ft[0]);g.awayGoals=Integer.parseInt(ft[1]);}catch(Exception ignored){}
            try{g.htHome=Integer.parseInt(ht[0]);g.htAway=Integer.parseInt(ht[1]);}catch(Exception ignored){}
            return g;}
    }
    public static final class Form {
        int teamId=-1;
        String warning="";
        final List<Game> games=new ArrayList<>();
        JSONObject json(){JSONObject j=new JSONObject();try{
            j.put("team_id",teamId).put("warning",warning);
            JSONArray a=new JSONArray();for(Game g:games)a.put(g.json());j.put("games",a);
        }catch(Exception ignored){}return j;}
        static Form fromJson(JSONObject j){Form f=new Form();if(j==null)return f;
            f.teamId=j.optInt("team_id",-1);f.warning=j.optString("warning","");
            JSONArray a=j.optJSONArray("games");if(a!=null)for(int i=0;i<a.length();i++){
                JSONObject g=a.optJSONObject(i);if(g!=null)f.games.add(Game.fromJson(g));}
            return f;
        }
        String summary(String name){
            int n=games.size(),allGF=0,allGA=0,firstN=0,firstGF=0,firstGA=0,firstOver15=0,
                    firstOver25=0,ftOver25=0,btts=0,homeN=0,homeGF=0,homeGA=0,awayN=0,awayGF=0,awayGA=0;
            for(Game g:games){
                int gf=g.atHome?g.homeGoals:g.awayGoals,ga=g.atHome?g.awayGoals:g.homeGoals;
                allGF+=gf;allGA+=ga;if(g.homeGoals+g.awayGoals>=3)ftOver25++;
                if(g.homeGoals>0&&g.awayGoals>0)btts++;
                if(g.atHome){homeN++;homeGF+=gf;homeGA+=ga;}
                else {awayN++;awayGF+=gf;awayGA+=ga;}
                if(g.htHome>=0&&g.htAway>=0){firstN++;
                    firstGF+=g.atHome?g.htHome:g.htAway;
                    firstGA+=g.atHome?g.htAway:g.htHome;
                    if(g.htHome+g.htAway>=2)firstOver15++;
                    if(g.htHome+g.htAway>=3)firstOver25++;
                }
            }
            StringBuilder sb=new StringBuilder(name+"\n");
            if(n==0){sb.append("历史样本不足：").append(warning).append("\n");return sb.toString();}
            sb.append("最近").append(n).append("场完赛：场均全场进球/失球 ").append(avg(allGF,n)).append("/").append(avg(allGA,n))
              .append("；全场总进球≥3：").append(ftOver25).append("/").append(n)
              .append("；双方均进球：").append(btts).append("/").append(n).append("\n");
            if(firstN>0){sb.append("有半场记录").append(firstN).append("场：场均半场进球/失球 ")
              .append(avg(firstGF,firstN)).append("/").append(avg(firstGA,firstN))
              .append("；半场总球≥2：").append(firstOver15).append("/").append(firstN)
              .append("；半场总球≥3：").append(firstOver25).append("/").append(firstN).append("\n");}
            else sb.append("半场历史比分缺失，不能判断半场高进球倾向。\n");
            if(homeN>0)sb.append("其中主场").append(homeN).append("场：场均全场进/失球 ")
                  .append(avg(homeGF,homeN)).append("/").append(avg(homeGA,homeN)).append("\n");
            if(awayN>0)sb.append("其中客场").append(awayN).append("场：场均全场进/失球 ")
                  .append(avg(awayGF,awayN)).append("/").append(avg(awayGA,awayN)).append("\n");
            sb.append("最近赛果（全场；括号为半场）：\n");
            for(Game g:games){sb.append("  ").append(g.date).append(" ").append(g.home).append(" ")
                    .append(g.homeGoals).append("-").append(g.awayGoals).append(" ").append(g.away)
                    .append(" (").append(g.htHome<0?"半场缺失":g.htHome+"-"+g.htAway).append(")\n");}
            int recentN=Math.min(n,5),recentGF=0,recentGA=0,recentHalfN=0,recentHalf2=0,recentBtts=0;
            int earlierN=0,earlierGF=0,earlierGA=0;
            Set<String> competitions=new LinkedHashSet<>();
            for(int i=0;i<n;i++){
                Game g=games.get(i);
                if(!g.league.trim().isEmpty())competitions.add(g.league);
                int gf=g.atHome?g.homeGoals:g.awayGoals,ga=g.atHome?g.awayGoals:g.homeGoals;
                if(i<5){
                    recentGF+=gf;recentGA+=ga;
                    if(gf>0&&ga>0)recentBtts++;
                    if(g.htHome>=0&&g.htAway>=0){recentHalfN++;if(g.htHome+g.htAway>=2)recentHalf2++;}
                }else if(i<10){earlierN++;earlierGF+=gf;earlierGA+=ga;}
            }
            sb.append("近").append(recentN).append("场：全场场均进/失 ").append(avg(recentGF,recentN)).append("/")
              .append(avg(recentGA,recentN)).append("；双方均进球 ").append(recentBtts).append("/").append(recentN)
              .append("；有半场数据").append(recentHalfN).append("场，其中半场总球≥2：")
              .append(recentHalf2).append("/").append(recentHalfN).append("。\n");
            if(earlierN>0)sb.append("更早").append(earlierN).append("场：全场场均进/失 ")
                .append(avg(earlierGF,earlierN)).append("/").append(avg(earlierGA,earlierN))
                .append("；只供比较，不代表趋势必将延续。\n");
            if(competitions.size()>1)sb.append("赛事混合警告：样本含").append(competitions.size())
                .append("个不同赛事（").append(String.join("、",competitions)).append("），不能直接当作同联赛能力。\n");
            if(n<8||firstN<5)sb.append("样本不足以可靠推断半场进球习惯；请降低历史资料权重。\n");
            if(!warning.isEmpty())sb.append("资料备注：").append(warning).append("\n");
            return sb.toString();
        }
        private String avg(int n,int d){return String.format(Locale.US,"%.2f",d==0?0.0:(double)n/d);}
    }
    public String report(){return "【赛前两队历史参考（足球API真实已完赛数据）】\n"
            +"联赛："+league+"；赛季 "+season+"；赛事实时统计覆盖："+fixtureStatsCoverage+"\n"
            +"样本只来自本次比赛开始之前；全场均值不能直接替代上半场进球率。\n\n"
            +home.summary("主队 "+homeTeam)+"\n"+away.summary("客队 "+awayTeam)
            +"\n提醒：赛事可能混有杯赛或不同级别对手；样本小、球队换阵或不同联赛不可直接推导下一球概率。\n"
            +"早进球（0–15分钟）需逐场进球事件支持，这里没有编造该指标。\n"
            +(coverageWarning.isEmpty()?"":coverageWarning+"\n");}
    public JSONObject json(){JSONObject j=new JSONObject();try{
        j.put("fixture_id",fixtureId).put("league_id",leagueId).put("season",season)
         .put("home_team",homeTeam).put("away_team",awayTeam).put("league",league)
         .put("fixture_stats_coverage",fixtureStatsCoverage).put("coverage_warning",coverageWarning)
         .put("fetched_at",fetchedAt).put("home",home.json()).put("away",away.json());
    }catch(Exception ignored){}return j;}
    public static TeamResearch fromJson(JSONObject j){TeamResearch r=new TeamResearch();
        r.fixtureId=j.optInt("fixture_id",-1);r.leagueId=j.optInt("league_id",-1);r.season=j.optInt("season",-1);
        r.homeTeam=j.optString("home_team","");r.awayTeam=j.optString("away_team","");r.league=j.optString("league","");
        r.fixtureStatsCoverage=j.optString("fixture_stats_coverage","未知");r.coverageWarning=j.optString("coverage_warning","");
        r.fetchedAt=j.optLong("fetched_at",0);
        Form homeForm=Form.fromJson(j.optJSONObject("home")),awayForm=Form.fromJson(j.optJSONObject("away"));
        r.home.teamId=homeForm.teamId;r.home.warning=homeForm.warning;r.home.games.addAll(homeForm.games);
        r.away.teamId=awayForm.teamId;r.away.warning=awayForm.warning;r.away.games.addAll(awayForm.games);
        return r;
    }
}
