package com.scoreguard.ht;

import java.text.Normalizer;
import java.time.LocalDate;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Extract ONLY explicitly visible fixture identity from a screening image.
 *  No guesswork: missing fields stay empty. No fabricated IDs or kickoff times.
 */
final class MatchImageParser {
    private static final Pattern ID = Pattern.compile(
            "(?i)(?:fixture\\s*(?:id|1d|ld)|match\\s*id|比赛\\s*(?:id|编号)|赛事\\s*(?:id|编号))\\s*[#:：]?\\s*([1-9][0-9]{4,9})");
    private static final Pattern DATE = Pattern.compile(
            "\\b(20[0-9]{2})[-/.年]([01]?[0-9])[-/.月]([0-3]?[0-9])(?:日)?\\s+([012]?[0-9]):([0-5][0-9])\\b");
    private static final Pattern DATE_ONLY = Pattern.compile(
            "\\b(20[0-9]{2})[-/.年]([01]?[0-9])[-/.月]([0-3]?[0-9])(?:日)?\\b");
    private static final Pattern VERSUS = Pattern.compile(
            "(?im)^\\s*([\\p{L}][\\p{L}\\p{M}0-9 .’'()&/-]{1,65}?)\\s+(?:vs\\.?|versus|v\\.)\\s+([\\p{L}][\\p{L}\\p{M}0-9 .’'()&/-]{1,65}?)\\s*$");
    final int fixtureId;
    final String date, time, home, away;

    private MatchImageParser(int id,String date,String time,String home,String away){
        fixtureId=id;this.date=date;this.time=time;this.home=home;this.away=away;
    }
    static MatchImageParser parse(String raw){
        String src=(raw==null?"":raw).replace('：',':').replace('\u00a0',' ')
                .replace('｜','|').replace('—','-');
        Matcher id=ID.matcher(src);
        int fixtureId=-1;
        if(id.find())try {fixtureId=Integer.parseInt(id.group(1));}catch(NumberFormatException ignored){}
        String date="",time="";
        Matcher d=DATE.matcher(src);
        if(d.find()){
            try{
                date=LocalDate.of(Integer.parseInt(d.group(1)),Integer.parseInt(d.group(2)),Integer.parseInt(d.group(3))).toString();
                int hour=Integer.parseInt(d.group(4));
                if(hour<=23)time=String.format(Locale.ROOT,"%02d:%s",hour,d.group(5));
                else date="";
            }catch(Exception ignored){date="";time="";}
        } else {
            d=DATE_ONLY.matcher(src);
            if(d.find())try{date=LocalDate.of(Integer.parseInt(d.group(1)),Integer.parseInt(d.group(2)),Integer.parseInt(d.group(3))).toString();}
            catch(Exception ignored){}
        }
        String home="",away="";
        Matcher teams=VERSUS.matcher(src);
        while(teams.find()){
            String h=teams.group(1).trim(),a=teams.group(2).trim();
            if(h.length()>2&&a.length()>2&&!h.matches("(?i)fixture.*")&&!a.matches("(?i)fixture.*")){
                home=h;away=a;break;
            }
        }
        return new MatchImageParser(fixtureId,date,time,home,away);
    }
    boolean hasTeams(){return !home.isEmpty()&&!away.isEmpty();}
    boolean useful(){return fixtureId>0||hasTeams();}
    String description(){
        return "比赛ID："+(fixtureId>0?fixtureId:"未识别")
                +"\n主队："+(home.isEmpty()?"未识别":home)
                +"\n客队："+(away.isEmpty()?"未识别":away)
                +"\n开赛时间（图片显示）："+(date.isEmpty()?"未识别":date)+(time.isEmpty()?"":" "+time)
                +"\n提示：可直接填写 Fixture ID；查询后仍须核对球队和开赛日期。";
    }
    static String norm(String s){
        return Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD)
                .replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+"," ").trim();
    }
    static boolean sameTeam(String expected,String actual){
        String e=norm(expected),a=norm(actual);
        if(e.isEmpty()||a.isEmpty())return false;
        if(e.equals(a))return true;
        // Allow small "FC", "SC" affix differences or OCR missing accent marks.
        if(e.length()>=7&&a.contains(e))return true;
        if(a.length()>=7&&e.contains(a))return true;
        String[] ignored={"fc","sc","club","deportivo","sporting","atletico","football","united","real","cf","ac","cd","fk","the","city"};
        String common=" "+String.join(" ",ignored)+" ";
        int meaningful=0,matched=0;
        for(String token:e.split(" ")){
            if(token.length()<4||common.contains(" "+token+" "))continue;
            meaningful++;
            for(String other:a.split(" "))if(other.equals(token)){matched++;break;}
        }
        return meaningful>0&&matched==meaningful;
    }
    boolean teamsMatch(Models.Fixture candidate){
        return !hasTeams()||(sameTeam(home,candidate.home)&&sameTeam(away,candidate.away));
    }
}
