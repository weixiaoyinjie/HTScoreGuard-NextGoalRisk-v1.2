# HT ScoreGuard v1.3 — 图片比赛身份核验修复版

独立 Android App：**主单 / 保险单仅输入比分，不填写金额、赔率，结算由用户手动操作。** 其余双方下一球风险、历史球队资料和可选 AI 联网分析功能保留。

## v1.3 修复内容

1. **Fixture ID 优先**：从筛选图片识别 `Fixture ID: 1648801`，自动填入可编辑的「比赛 Fixture ID」，向足球 API 发起 `GET /fixtures?id=1648801`；若接口没有返回比赛，就明确报错，**不会用不相关球队替代**。
2. **识别球队和时间**：解析 `2026-11-14 15:30 开赛` 和 `Villa Dalmine vs Deportivo Camioneros`，在页面展示主队、客队、原图片时间、ID。支持编辑 OCR 文本和直接手动输入 Fixture ID。
3. **完整显示 OCR**：修复原46dp固定高度导致第二、三行无法显示的问题，改为132dp多行输入区。
4. **二次 OCR**：如果第一遍ML Kit没有同时识别ID和双方球队，先对黑底白字筛选图增强对比度后再识别一次，合并结果。实际效果仍取决于截图质量。
5. **阻止错误确认**：图片有ID时只返回该ID；球队或日期与 API 不匹配时提示错误并停止，不再错误地确认 `Renate vs Desenzano Calvina`。
6. **清除旧比赛**：换一张截图或重新搜索时，解除此前确认的比赛，防止旧 Fixture ID 用于新场次。
7. **搜索回退**：没有识别ID时，可根据图片中的主客队以及图片日期查询；仅列出两个队名匹配的比赛。日期按图片日期±1天查询，不会只按设备今天日期猜测。

## 示例截图预期

```
比赛ID：1648801
主队：Villa Dalmine
客队：Deportivo Camioneros
开赛时间（图片显示）：2026-11-14 15:30
```

API 结果必须再核验才能点击「确认选中比赛」。如果图片名字识别错误，允许更正OCR输入框；如果Fixture ID不清楚，可以直接手动输入。

**注意**：Fixture ID是筛选App的来源ID，只有与当前配置的 API-Football 为同一供应商时才可直接查询。如果来自其他数据商的ID，可能查不到；这时可清空ID，用双方队名、图片日期搜索，并人工核对。

## 其他现有功能

- 2张或3张上半场比分单（主单、保险单1、保险单2）；只填正确比分。
- 目标比分达到后，分别追踪主队下一球、客队下一球的最新活动与趋势。
- 前台每分钟采集快照；只有积累真实快照才计算5～10分钟变化。不会把不存在的xG当成已取得数据。
- 球队最近完赛比赛、半场进失球研究；可选AI联网查询出处。
- 没有可靠数据直接提示不足／仅供人工判断，不自动结算。

## 用GitHub Actions编译（支持仓库直接上传ZIP）

方法A：解压此ZIP，将全部文件上传至仓库根目录。由于工程自带`.github/workflows/android.yml`，GitHub Actions会识别完整Android项目，执行 `Build standalone ScoreGuard APK`。

方法B：若原仓库仅上传整个源码ZIP，可以将新版ZIP文件 `HTScoreGuard_v1_3_FixtureID_OCR_FIXED_OneUpload.zip` 作为一个文件上传仓库根目录，再把工作流 `.github/workflows/android.yml` 替换为单独提供的 `HTScoreGuard_v1_3_GitHub_Workflow.yml` 内容。工作流会自动解压新版ZIP并编译。不要只上传ZIP而不替换旧工作流，否则仍然编译旧源码。

环境：GitHub Ubuntu 24.04，Java17，Gradle8.9，Android SDK 35，`android.useAndroidX=true`。成功后 Artifact：`HTScoreGuard-v1_3-debug-apk`。

代码级OCR解析单元测试包括本次图片中的Fixture ID、球队及时间、识别误差、同名常见词防误配。此环境没有Android SDK/Gradle运行器，**尚未实际完成 APK 编译或真机验证**；需要GitHub Actions确认。原 `app-debug.apk` 是旧版本，不能通过修改APK直接修复。
