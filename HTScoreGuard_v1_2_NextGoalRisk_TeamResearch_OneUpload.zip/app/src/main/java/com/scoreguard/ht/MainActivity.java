package com.scoreguard.ht;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.util.Linkify;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Standalone manual settlement-decision research tool. No bookmaker transactions. */
public final class MainActivity extends Activity {
    private final int BG=0xfff4f6f9, TEXT=0xff162333, MUTED=0xff596779, BLUE=0xff194e85, GREEN=0xff11725d;
    private static final int REQUEST_IMAGE=101;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final AtomicBoolean fetching=new AtomicBoolean(false);
    private LinearLayout body, betsArea;
    private EditText footballKey,aiKey,modelName,manualMatch,ocrPreview;
    private TextView liveStatus,selection,localReport,aiReport,snapshotStatus,researchReport;
    private TextView homeRisk,awayRisk,riskDecision;
    private CheckBox aiWeb;
    private Spinner matchSpinner,betCount;
    private final List<Models.Fixture> matches=new ArrayList<>();
    private final ArrayList<BetInputs> inputs=new ArrayList<>();
    private int fixtureId=-1;
    private String ocrText="";
    private boolean restoring=false;
    private final Runnable poller=new Runnable(){
        @Override public void run(){
            if(fixtureId>0&&!Secrets.get(MainActivity.this,"football").isEmpty())silentPoll();
            handler.postDelayed(this,60_000);
        }
    };

    private static final class BetInputs {
        String label;
        EditText score;
    }
    private interface DataAction {void apply() throws Exception;}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().setStatusBarColor(0xff0e2e4f);
        buildUi();restoreState();
    }
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(poller);handler.postDelayed(poller,60_000);}
    @Override protected void onPause(){handler.removeCallbacks(poller);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(poller);io.shutdown();super.onDestroy();}

    private SharedPreferences prefs(){return getSharedPreferences("scoreguard_state",MODE_PRIVATE);}
    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+0.5f);}
    private GradientDrawable bg(int color,float radius){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;
    }
    private TextView label(String txt,int size,int color,boolean bold){
        TextView v=new TextView(this);v.setText(txt);v.setTextColor(color);v.setTextSize(size);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(dp(2),dp(4),dp(2),dp(4));
        return v;
    }
    private LinearLayout section(String title,String desc){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16),dp(14),dp(16),dp(15));card.setBackground(bg(Color.WHITE,16));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(dp(12),dp(8),dp(12),dp(6));
        body.addView(card,cp);
        card.addView(label(title,18,TEXT,true));
        if(desc!=null&&!desc.isEmpty())card.addView(label(desc,13,MUTED,false));
        return card;
    }
    private EditText field(LinearLayout parent,String hint,String value,boolean numeric){
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(15);e.setTextColor(TEXT);
        e.setHint(hint);e.setHintTextColor(0xff8090a0);e.setPadding(dp(10),dp(9),dp(10),dp(9));
        e.setBackground(bg(BG,9));e.setInputType(numeric?(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL|InputType.TYPE_NUMBER_FLAG_SIGNED)
                :InputType.TYPE_CLASS_TEXT);
        e.setText(value);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(46));p.setMargins(0,dp(5),0,dp(5));
        parent.addView(e,p);return e;
    }
    private Button button(LinearLayout parent,String text,boolean primary,View.OnClickListener action){
        Button b=new Button(this);b.setText(text);b.setTextSize(14);b.setAllCaps(false);
        b.setTextColor(primary?Color.WHITE:BLUE);b.setBackground(bg(primary?BLUE:0xffedf4fa,10));
        b.setOnClickListener(action);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(49));p.setMargins(0,dp(6),0,dp(4));
        parent.addView(b,p);return b;
    }
    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(0,0,0,dp(28));
        scroll.addView(body);setContentView(scroll);
        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(22),dp(28),dp(22),dp(25));hero.setBackground(bg(0xff0e2e4f,0));
        hero.addView(label("HT ScoreGuard",26,Color.WHITE,true));
        hero.addView(label("半场目标比分 · 人工结算分析",15,0xffd4e9fc,false));
        hero.addView(label("主队下一球 ↑/↓  ·  客队下一球 ↑/↓  ·  人工决定是否结算",12,0xffb3cfe6,false));
        body.addView(hero,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout cfg=section("① 连接足球API和AI API","密钥只在本机加密保存；不写进源码或APK。AI分析可选，离线规则报告始终保留。");
        footballKey=field(cfg,"API-Football 密钥（留空则保留原值）","",false);
        footballKey.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        aiKey=field(cfg,"OpenAI API 密钥（留空则保留原值）","",false);
        aiKey.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        modelName=field(cfg,"模型名称，例如 gpt-4.1-mini","gpt-4.1-mini",false);
        aiWeb=new CheckBox(this);aiWeb.setText("允许AI联网查找球队资料及资料来源（额外API成本）");
        aiWeb.setTextSize(13);aiWeb.setTextColor(MUTED);aiWeb.setChecked(true);cfg.addView(aiWeb);
        button(cfg,"保存API配置",false,v->saveKeys());

        LinearLayout img=section("② 导入筛选图片并确认比赛","从手机相册选择之前筛选App生成的图片。识别结果只用于寻找候选比赛，必须人工确认。");
        button(img,"从相册导入筛选图片",true,v->chooseImage());
        manualMatch=field(img,"可选：输入英文队名或部分队名帮助匹配","",false);
        ocrPreview=field(img,"图片识别到的文字（也可手动修正）","",false);
        ocrPreview.setSingleLine(false);ocrPreview.setMinLines(2);
        button(img,"搜索并排列候选比赛",false,v->searchMatches());
        matchSpinner=new Spinner(this);img.addView(matchSpinner,new LinearLayout.LayoutParams(-1,dp(54)));
        selection=label("未选择比赛",14,MUTED,false);img.addView(selection);
        button(img,"确认选中比赛",true,v->confirmMatch());

        LinearLayout bets=section("③ 设置比分主单和保险单","只需输入主单和保险单的上半场正确比分；无需填写金额、赔率或结算报价。");
        betCount=new Spinner(this);
        ArrayAdapter<String> countAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,
                new String[]{"2张：主单 + 保险单","3张：主单 + 两张保险单"});
        betCount.setAdapter(countAdapter);bets.addView(betCount,new LinearLayout.LayoutParams(-1,dp(48)));
        betsArea=new LinearLayout(this);betsArea.setOrientation(LinearLayout.VERTICAL);bets.addView(betsArea);
        betCount.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){
                if(!restoring && inputs.size()!=(pos==0?2:3))rebuildBets(pos==0?2:3);
            }
            @Override public void onNothingSelected(AdapterView<?> p){}
        });
        button(bets,"保存比赛与比分单",false,v->saveState());

        LinearLayout analysis=section("④ 点击：分析现在是否适合结算","例如20分钟达到1-0，25分钟点击下方按钮。App抓取实时数据、球队历史和可选AI网页资料，前台每60秒采样。");
        liveStatus=label("等待比赛确认",15,GREEN,true);analysis.addView(liveStatus);
        snapshotStatus=label("尚无快照",13,MUTED,false);analysis.addView(snapshotStatus);
        analysis.addView(label("目标比分出现后：分别监控两队下一球",16,BLUE,true));
        LinearLayout riskRow=new LinearLayout(this);riskRow.setOrientation(LinearLayout.HORIZONTAL);
        riskRow.setPadding(0,dp(8),0,dp(5));analysis.addView(riskRow);
        homeRisk=riskPane(riskRow,"主队再进球", "未分析");
        awayRisk=riskPane(riskRow,"客队进球", "未分析");
        riskDecision=label("尚未取得可判断的真实数据",14,BLUE,true);analysis.addView(riskDecision);
        button(analysis,"立即分析：足球API + AI球队资料",true,v->analyzeNow());
        button(analysis,"刷新双方下一球风险（不调用AI）",false,v->manualSnapshot());
        localReport=label("这里将显示实时比分、双方统计、最近5～10分钟变化和比分单风险证据。",14,TEXT,false);
        localReport.setTextIsSelectable(true);analysis.addView(localReport);
        TextView researchTitle=label("赛前球队资料（足球API历史完赛记录）",17,BLUE,true);
        analysis.addView(researchTitle);
        researchReport=label("待分析：双方最近完赛纪录、半场进失球、历史高比分倾向与数据覆盖。",14,TEXT,false);
        researchReport.setTextIsSelectable(true);analysis.addView(researchReport);
        TextView heading=label("AI交叉分析及联网来源",17,BLUE,true);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(16);
        analysis.addView(heading,hp);
        aiReport=label("AI以真实API数据为主，联网补充可核实的球队近况。没有资料会标明无法确认。",14,TEXT,false);
        aiReport.setTextIsSelectable(true);
        aiReport.setAutoLinkMask(Linkify.WEB_URLS);
        aiReport.setLinksClickable(true);
        analysis.addView(aiReport);

        LinearLayout notes=section("⑤ 使用纪律与限制","上半场补时可能超过45'；数据质量不足时PASS。此App不连接投注平台，也不会自动结算。");
        notes.addView(label("提示：• 最近5～10分钟变化依赖App已经保存的快照，首次打开不能重建。\n"
                        +"• 主队再进球、客队进球必须分别判断。\n"
                        +"• 历史全场进球率与半场进球率要分开，不混淆。\n"
                        +"• 低级别联赛数据可能不全，AI不得虚构记录。\n"
                        +"• 本地规则未经回测校准，只辅助人工判断。",13,MUTED,false));
    }
    private TextView riskPane(LinearLayout parent,String title,String initial){
        LinearLayout pane=new LinearLayout(this);pane.setOrientation(LinearLayout.VERTICAL);
        pane.setPadding(dp(10),dp(10),dp(10),dp(10));pane.setBackground(bg(0xffedf4fa,12));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
        lp.setMargins(dp(3),0,dp(3),0);parent.addView(pane,lp);
        pane.addView(label(title,14,BLUE,true));
        TextView value=label(initial,12,TEXT,false);pane.addView(value);return value;
    }
    private void showDirectional(RiskEngine.Result r){
        homeRisk.setText(r.homeSignal+"\n"+r.homeTrend+"\n"+r.homeDetail);
        awayRisk.setText(r.awaySignal+"\n"+r.awayTrend+"\n"+r.awayDetail);
        homeRisk.setTextColor(r.homeSignal.contains("警戒")?0xffa23a1a:TEXT);
        awayRisk.setTextColor(r.awaySignal.contains("警戒")?0xffa23a1a:TEXT);
        riskDecision.setText("当前结论："+r.label+"\n"+(r.targetMatched?
              "至少一张比分单已匹配；持续关注任一方下一球。":"未出现任何输入的目标比分；暂不做持有判断。"));
    }
    private void toast(String t){Toast.makeText(this,t,Toast.LENGTH_LONG).show();}
    private void status(String text){liveStatus.setText(text);}
    private void saveKeys(){
        try{
            String k=footballKey.getText().toString().trim(),ai=aiKey.getText().toString().trim();
            if(!k.isEmpty())Secrets.put(this,"football",k);
            if(!ai.isEmpty())Secrets.put(this,"ai",ai);
            prefs().edit().putString("model",modelName.getText().toString().trim())
                    .putBoolean("ai_web",aiWeb.isChecked()).apply();
            footballKey.setText("");aiKey.setText("");
            toast("配置已保存在本机；未输入的密钥保持不变");
        }catch(Exception e){toast("保存失败："+e.getMessage());}
    }
    private void chooseImage(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");
        startActivityForResult(i,REQUEST_IMAGE);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=REQUEST_IMAGE||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();status("正在识别图片中的比赛信息…");
        try{
            InputImage image=InputImage.fromFilePath(this,uri);
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener(resultText->{
                        ocrText=resultText.getText();ocrPreview.setText(ocrText);
                        status("识别完成，点击搜索候选比赛");
                        if(ocrText.trim().isEmpty())toast("没有识别到文字，可以手动输入队名");
                    })
                    .addOnFailureListener(e->status("图片识别失败："+e.getMessage()));
        }catch(Exception e){status("无法打开图片："+e.getMessage());}
    }
    private void doBg(Runnable work){io.execute(work);}
    private void searchMatches(){
        saveState();
        String key=Secrets.get(this,"football");
        if(key.isEmpty()){toast("请先填写并保存足球API Key");return;}
        String ocr=ocrPreview.getText().toString(),query=manualMatch.getText().toString();
        status("正在从足球API匹配比赛…");
        doBg(()->{
            try{
                List<Models.Fixture> found=new FootballApi(key).findCandidates(ocr,query);
                runOnUiThread(()->setCandidates(found));
            }catch(Exception e){runOnUiThread(()->status("比赛匹配失败："+e.getMessage()));}
        });
    }
    private void setCandidates(List<Models.Fixture> found){
        matches.clear();matches.addAll(found);
        List<String> names=new ArrayList<>();for(Models.Fixture f:found)names.add(f.display()+" · "+f.status);
        if(names.isEmpty())names.add("没有找到候选比赛，请检查密钥/日期/队名");
        matchSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        status("找到"+found.size()+"场候选；请核对联赛、主客、日期，选择后再确认。");
    }
    private void confirmMatch(){
        int index=matchSpinner.getSelectedItemPosition();
        if(index<0||index>=matches.size()){toast("请先搜索并选择正确的比赛");return;}
        Models.Fixture f=matches.get(index);
        fixtureId=f.id;selection.setText("已确认比赛 #"+f.id+" · "+f.display());
        saveState();status("已确认比赛："+f.home+" vs "+f.away+"，可开始采样和分析");
    }
    private void rebuildBets(int wanted){
        ArrayList<Models.Bet> existing=new ArrayList<>();
        for(BetInputs row:inputs)existing.add(readBet(row));
        inputs.clear();betsArea.removeAllViews();
        for(int i=0;i<wanted;i++){
            String lab=i==0?"主单":(i==1?"保险单1":"保险单2");
            Models.Bet saved=i<existing.size()?existing.get(i):new Models.Bet(lab);
            addBetRow(lab,saved);
        }
    }
    private void addBetRow(String lab,Models.Bet saved){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(bg(BG,10));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(7),0,dp(7));
        betsArea.addView(card,lp);card.addView(label(lab,15,BLUE,true));
        BetInputs b=new BetInputs();b.label=lab;
        b.score=field(card,"半场正确比分（例：1-0）",saved.score,false);
        inputs.add(b);
    }
    private Models.Bet readBet(BetInputs input){
        Models.Bet b=new Models.Bet(input.label);
        b.score=input.score.getText().toString().trim().replace('：','-').replace(':','-').replace('－','-').replaceAll("\\s+","");
        return b;
    }
    private Models.Portfolio portfolio(){Models.Portfolio p=new Models.Portfolio();
        for(BetInputs row:inputs)p.bets.add(readBet(row));return p;
    }
    private void saveState(){
        try{
            prefs().edit().putInt("id",fixtureId)
                    .putString("ocr",ocrPreview.getText().toString())
                    .putString("manual",manualMatch.getText().toString())
                    .putInt("count",inputs.size())
                    .putString("bets",portfolio().json().toString())
                    .putString("selection",selection.getText().toString())
                    .putString("model",modelName.getText().toString())
                    .putBoolean("ai_web",aiWeb.isChecked()).apply();
            toast("比赛和单据已保存（API密钥单独加密）");
        }catch(Exception e){toast("保存异常："+e.getMessage());}
    }
    private void restoreState(){
        restoring=true;
        fixtureId=prefs().getInt("id",-1);
        ocrText=prefs().getString("ocr","");ocrPreview.setText(ocrText);
        manualMatch.setText(prefs().getString("manual",""));
        modelName.setText(prefs().getString("model","gpt-4.1-mini"));
        aiWeb.setChecked(prefs().getBoolean("ai_web",true));
        selection.setText(prefs().getString("selection","未确认比赛"));
        int count=prefs().getInt("count",2);betCount.setSelection(count==3?1:0);
        Models.Portfolio saved;
        try{saved=Models.Portfolio.fromJson(new JSONArray(prefs().getString("bets","[]")));}
        catch(Exception ignored){saved=new Models.Portfolio();}
        for(int i=0;i<count;i++)addBetRow(i==0?"主单":i==1?"保险单1":"保险单2",
                i<saved.bets.size()?saved.bets.get(i):new Models.Bet(""));
        if(fixtureId>0)status("已保存比赛 #"+fixtureId+"；点击分析可更新数据");
        snapshotStatus.setText("本机已有 "+loadHistory().size()+" 个快照；需连续快照才能计算近期变化");
        restoring=false;
    }
    private ArrayList<Models.Snapshot> loadHistory(){
        ArrayList<Models.Snapshot> snapshots=new ArrayList<>();
        if(fixtureId<1)return snapshots;
        try{
            JSONArray a=new JSONArray(prefs().getString("history_"+fixtureId,"[]"));
            for(int i=0;i<a.length();i++){JSONObject obj=a.optJSONObject(i);if(obj!=null)snapshots.add(Models.Snapshot.fromJson(obj));}
        }catch(Exception ignored){}
        return snapshots;
    }
    private Models.Snapshot findPrevious(List<Models.Snapshot> history,Models.Snapshot now){
        Models.Snapshot best=null;int bestDist=1000;
        for(Models.Snapshot x:history){
            int delta=now.fixture.minute-x.fixture.minute;
            if(delta<1||delta>10)continue;
            int distance=Math.abs(delta-5);
            if(distance<bestDist){best=x;bestDist=distance;}
        }
        return best;
    }
    private void storeHistory(Models.Snapshot now){
        if(fixtureId<1||now.fixture.minute<0)return;
        ArrayList<Models.Snapshot> h=loadHistory();
        // Same-minute observations replace old counters; only valid in-play first-half snapshots are comparable.
        h.removeIf(s->s.fixture.minute==now.fixture.minute||
                (now.fixture.minute<s.fixture.minute&&"1H".equals(now.fixture.status)));
        h.add(now);
        h.sort(Comparator.comparingInt(s->s.fixture.minute));
        while(h.size()>65)h.remove(0);
        JSONArray a=new JSONArray();for(Models.Snapshot s:h)a.put(s.json());
        prefs().edit().putString("history_"+fixtureId,a.toString()).apply();
    }
    private Models.Snapshot findBefore(List<Models.Snapshot> history,Models.Snapshot earlier){
        return earlier==null?null:findPrevious(history,earlier);
    }
    private void manualSnapshot(){
        saveWithoutToast();
        if(fixtureId<1){toast("请先确认比赛");return;}
        if(fetching.getAndSet(true)){toast("已有数据请求在进行");return;}
        final int requestedFixture=fixtureId;
        final Models.Portfolio p=portfolio();
        status("正在更新双方下一球风险…");
        doBg(()->{
            try{
                Models.Snapshot s=new FootballApi(Secrets.get(this,"football")).fetch(requestedFixture);
                if(requestedFixture!=fixtureId)return;
                ArrayList<Models.Snapshot> h=loadHistory();
                Models.Snapshot old=findPrevious(h,s),before=findBefore(h,old);
                RiskEngine.Result r=RiskEngine.evaluate(s,old,before,p);
                storeHistory(s);
                runOnUiThread(()->{
                    status(s.fixture.liveDisplay());snapshotStatus.setText("已存快照："+loadHistory().size()+" 个；最新 "+s.fixture.minute+"'");
                    showDirectional(r);localReport.setText(r.message);
                });
            }catch(Exception e){runOnUiThread(()->status("抓取失败："+e.getMessage()));}
            finally{fetching.set(false);}
        });
    }
    private void silentPoll(){
        if(!fetching.compareAndSet(false,true))return;
        final int id=fixtureId;
        final Models.Portfolio p=portfolio();
        doBg(()->{
            try{
                Models.Snapshot s=new FootballApi(Secrets.get(this,"football")).fetch(id);
                if(id==fixtureId){
                    ArrayList<Models.Snapshot> h=loadHistory();
                    Models.Snapshot old=findPrevious(h,s),before=findBefore(h,old);
                    RiskEngine.Result r=RiskEngine.evaluate(s,old,before,p);
                    storeHistory(s);
                    runOnUiThread(()->{
                        snapshotStatus.setText("前台自动监控："+s.fixture.minute+"'，已有"+loadHistory().size()+"条快照");
                        showDirectional(r);localReport.setText(r.message);
                        status(s.fixture.liveDisplay());
                    });
                }
            }catch(Exception ignored){ /* Explicit analysis displays errors; background sampling is best effort. */ }
            finally{fetching.set(false);}
        });
    }
    private void saveWithoutToast(){
        prefs().edit().putInt("id",fixtureId).putInt("count",inputs.size())
             .putString("bets",portfolio().json().toString())
             .putString("ocr",ocrPreview.getText().toString()).putString("manual",manualMatch.getText().toString())
             .putString("model",modelName.getText().toString())
                    .putBoolean("ai_web",aiWeb.isChecked()).apply();
    }
    /** Cache pre-match team form separately from fresh live stats to avoid repeated quota use. */
    private TeamResearch loadOrFetchResearch(Models.Fixture fixture,String key){
        try{
            String raw=prefs().getString("research_"+fixture.id,"");
            if(!raw.isEmpty()){
                TeamResearch cached=TeamResearch.fromJson(new JSONObject(raw));
                if(cached.fixtureId==fixture.id && System.currentTimeMillis()-cached.fetchedAt<6*60*60*1000L)
                    return cached;
            }
        }catch(Exception ignored){}
        TeamResearch r=new FootballApi(key).fetchResearch(fixture);
        prefs().edit().putString("research_"+fixture.id,r.json().toString()).apply();
        return r;
    }
    private void analyzeNow(){
        if(fixtureId<1){toast("请先识别图片并确认比赛");return;}
        String key=Secrets.get(this,"football");if(key.isEmpty()){toast("请配置足球API Key");return;}
        saveWithoutToast();
        Models.Portfolio p=portfolio();
        for(Models.Bet b:p.bets){
            if(!b.score.matches("\\d+-\\d+")){
                toast("请填写"+b.label+"的正确比分，例如 1-0");return;
            }
        }
        if(!fetching.compareAndSet(false,true)){toast("正在抓取数据，请勿重复点击");return;}
        String ai=Secrets.get(this,"ai"),model=modelName.getText().toString();
        boolean webResearch=aiWeb.isChecked();
        status("正在核对实时比分、事件、双方射门及历史快照…");
        doBg(()->{
            try{
                Models.Snapshot s=new FootballApi(key).fetch(fixtureId);
                ArrayList<Models.Snapshot> history=loadHistory();
                Models.Snapshot old=findPrevious(history,s),before=findBefore(history,old);
                RiskEngine.Result report=RiskEngine.evaluate(s,old,before,p);
                storeHistory(s);
                runOnUiThread(()->{
                    status(s.fixture.liveDisplay()+" · "+report.label);
                    snapshotStatus.setText("最新快照已保存，现有"+loadHistory().size()+"条；"+(old==null?"缺历史窗口":"比较 "+old.fixture.minute+"'→"+s.fixture.minute+"'"));
                    localReport.setText(report.message);
                    showDirectional(report);
                    aiReport.setText(ai.isEmpty()?"AI未配置。请依据上方真实数据进行人工判断。":"正在AI独立核对双方下一球风险…");
                });
                TeamResearch research=null;
                try{
                    research=loadOrFetchResearch(s.fixture,key);
                    TeamResearch data=research;
                    runOnUiThread(()->researchReport.setText(data.report()));
                }catch(Exception e){
                    runOnUiThread(()->researchReport.setText("球队历史参考查询失败，不能据此判断："+e.getMessage()));
                }
                if(!ai.isEmpty()){
                    try{
                        String text=AiClient.analyze(ai,model,s,old,before,p,research,report.message,webResearch);
                        runOnUiThread(()->aiReport.setText(text));
                    }catch(Exception e){runOnUiThread(()->aiReport.setText("AI请求失败，但本地报告有效："+e.getMessage()));}
                }
            }catch(Exception e){runOnUiThread(()->status("分析失败："+e.getMessage()));}
            finally{fetching.set(false);}
        });
    }
}
