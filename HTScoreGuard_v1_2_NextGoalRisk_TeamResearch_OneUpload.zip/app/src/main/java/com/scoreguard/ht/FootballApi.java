package com.scoreguard.ht;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

final class FootballApi {
    static final String BASE="https://v3.football.api-sports.io";
    static final String[] STAT_TYPES={"Shots on Goal","Shots off Goal","Total Shots",
            "Shots insidebox","Shots outsidebox","Blocked Shots","Corner Kicks",
            "Yellow Cards","Red Cards","Ball Possession","Fouls","Goalkeeper Saves"};
    private final String apiKey;
    FootballApi(String key){apiKey=key;}

    private JSONObject get(String path) throws Exception {
        if(apiKey==null||apiKey.trim().isEmpty())throw new IllegalStateException("请先填写足球API Key");
        HttpURLConnection c=(HttpURLConnection)new URL(BASE+path).openConnection();
        try {
            c.setRequestMethod("GET"); c.setRequestProperty("x-apisports-key",apiKey.trim());
            c.setRequestProperty("Accept","application/json"); c.setConnectTimeout(12000); c.setReadTimeout(18000);
            int code=c.getResponseCode();
            InputStream raw=code>=400?c.getErrorStream():c.getInputStream();
            if(raw==null)throw new IllegalStateException("足球API HTTP "+code);
            String body;
            try(InputStream in=raw; ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                byte[] buf=new byte[8192]; int n;
                while((n=in.read(buf))>=0) {out.write(buf,0,n);if(out.size()>12_000_000)throw new IllegalStateException("响应太大");}
                body=out.toString(StandardCharsets.UTF_8.name());
            }
            if(code>=400)throw new IllegalStateException("足球API HTTP "+code+": "+body.substring(0,Math.min(200,body.length())));
            JSONObject j=new JSONObject(body);
            JSONObject errs=j.optJSONObject("errors");
            if(errs!=null&&errs.length()>0)throw new IllegalStateException("足球API错误："+errs);
            return j;
        } finally {c.disconnect();}
    }

    static Models.Fixture parseFixture(JSONObject item) {
        Models.Fixture f=new Models.Fixture();
        JSONObject fixture=item.optJSONObject("fixture"); JSONObject teams=item.optJSONObject("teams");
        JSONObject goals=item.optJSONObject("goals"); JSONObject league=item.optJSONObject("league");
        if(fixture==null||teams==null)return f;
        f.id=fixture.optInt("id",-1); f.date=fixture.optString("date","");
        JSONObject status=fixture.optJSONObject("status");
        if(status!=null){f.minute=status.isNull("elapsed")?-1:status.optInt("elapsed",-1);f.status=status.optString("short","");}
        JSONObject home=teams.optJSONObject("home"),away=teams.optJSONObject("away");
        if(home!=null){f.home=home.optString("name","");f.homeId=home.optInt("id",-1);}
        if(away!=null){f.away=away.optString("name","");f.awayId=away.optInt("id",-1);}
        if(goals!=null){f.homeScore=goals.isNull("home")?-1:goals.optInt("home",-1);
            f.awayScore=goals.isNull("away")?-1:goals.optInt("away",-1);}
        if(league!=null){f.league=league.optString("name","");f.leagueId=league.optInt("id",-1);f.season=league.optInt("season",-1);}
        return f;
    }

    List<Models.Fixture> findCandidates(String ocr, String manualQuery) throws Exception {
        Map<Integer,Models.Fixture> unique=new HashMap<>();
        // Prioritize currently-live fixtures, then three date windows to accommodate timezone discrepancies.
        collect(unique,get("/fixtures?live=all").optJSONArray("response"));
        LocalDate day=LocalDate.now();
        for(int d=-1;d<=1;d++) {
            collect(unique,get("/fixtures?date="+day.plusDays(d)).optJSONArray("response"));
        }
        ArrayList<Models.Fixture> all=new ArrayList<>(unique.values());
        all.sort(Comparator.comparingDouble((Models.Fixture f)->-matchScore(f,ocr,manualQuery))
                .thenComparing((Models.Fixture f)->-liveRank(f)));
        if(all.size()>80)return new ArrayList<>(all.subList(0,80));
        return all;
    }
    private void collect(Map<Integer,Models.Fixture> dest, JSONArray arr) {
        if(arr==null)return;
        for(int i=0;i<arr.length();i++){JSONObject o=arr.optJSONObject(i);if(o==null)continue;
            Models.Fixture f=parseFixture(o);if(f.id>0)dest.put(f.id,f);}
    }
    private static int liveRank(Models.Fixture f){return "1H".equals(f.status)?3:"HT".equals(f.status)?2:"NS".equals(f.status)?1:0;}
    static String normalized(String s){
        String a=Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD)
                .replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT);
        return a.replaceAll("[^a-z0-9]+"," ").trim();
    }
    private static double scoreOne(String team,String text){
        String teamNorm=normalized(team); if(teamNorm.isEmpty()||text.isEmpty())return 0;
        if(text.contains(teamNorm))return 20;
        String[] parts=teamNorm.split(" ");double score=0;
        for(String part:parts){if(part.length()>=4&&text.contains(part))score+=5;}
        return score;
    }
    static double matchScore(Models.Fixture f,String ocr,String manual){
        String source=normalized(ocr), q=normalized(manual);
        double s=scoreOne(f.home,source)+scoreOne(f.away,source);
        if(!q.isEmpty())s+=scoreOne(f.home,q)*5+scoreOne(f.away,q)*5;
        return s+liveRank(f)*0.01;
    }

    /** Fetch prior completed matches only: excludes current/live/future fixtures. */
    TeamResearch fetchResearch(Models.Fixture fixture) {
        TeamResearch research=new TeamResearch();
        research.fixtureId=fixture.id;
        research.homeTeam=fixture.home;
        research.awayTeam=fixture.away;
        research.league=fixture.league;
        research.leagueId=fixture.leagueId;
        research.season=fixture.season;
        research.fetchedAt=System.currentTimeMillis();
        if(fixture.homeId>0)fetchFormInto(research.home,fixture.homeId,fixture);
        else research.home.warning="缺少主队Team ID";
        if(fixture.awayId>0)fetchFormInto(research.away,fixture.awayId,fixture);
        else research.away.warning="缺少客队Team ID";
        if(fixture.leagueId>0&&fixture.season>0){
            try{
                JSONArray data=get("/leagues?id="+fixture.leagueId+"&season="+fixture.season).optJSONArray("response");
                if(data!=null&&data.length()>0){
                    JSONObject first=data.optJSONObject(0);
                    JSONArray allSeasons=first==null?null:first.optJSONArray("seasons");
                    JSONObject seasons=null;
                    if(allSeasons!=null)for(int k=0;k<allSeasons.length();k++){
                        JSONObject t=allSeasons.optJSONObject(k);
                        if(t!=null&&t.optInt("year",-1)==fixture.season){seasons=t;break;}
                    }
                    if(seasons!=null){JSONObject coverage=seasons.optJSONObject("coverage");
                        if(coverage!=null){JSONObject fx=coverage.optJSONObject("fixtures");
                            if(fx!=null)research.fixtureStatsCoverage=fx.optBoolean("statistics_fixtures",false)?"覆盖标记为支持（不保证每场有数据）":"覆盖标记为不支持";
                        }
                    }
                }
            }catch(Exception e){research.coverageWarning="联赛覆盖查询失败："+e.getMessage();}
        }
        return research;
    }
    private void fetchFormInto(TeamResearch.Form out,int teamId,Models.Fixture current){
        out.teamId=teamId;
        try{
            JSONArray a=get("/fixtures?team="+teamId+"&last=25").optJSONArray("response");
            if(a==null){out.warning="未取得历史比赛";return;}
            for(int i=0;i<a.length()&&out.games.size()<10;i++){
                JSONObject j=a.optJSONObject(i); if(j==null)continue;
                Models.Fixture f=parseFixture(j);
                if(f.id==current.id||f.homeScore<0||f.awayScore<0)continue;
                if(!("FT".equals(f.status)||"AET".equals(f.status)||"PEN".equals(f.status)))continue;
                if(!current.date.isEmpty()&&!f.date.isEmpty()&&f.date.compareTo(current.date)>=0)continue;
                JSONObject scores=j.optJSONObject("score"),half=scores==null?null:scores.optJSONObject("halftime");
                TeamResearch.Game game=new TeamResearch.Game();
                game.fixtureId=f.id;game.date=f.date.length()>=10?f.date.substring(0,10):f.date;
                game.league=f.league;game.home=f.home;game.away=f.away;
                game.homeGoals=f.homeScore;game.awayGoals=f.awayScore;game.atHome=f.homeId==teamId;
                if(half!=null){game.htHome=half.isNull("home")?-1:half.optInt("home",-1);
                    game.htAway=half.isNull("away")?-1:half.optInt("away",-1);}
                out.games.add(game);
            }
            out.games.sort((first,second)->second.date.compareTo(first.date));
            if(out.games.isEmpty())out.warning="没有足够赛前已完赛数据，不能根据队名猜测进球习惯";
        }catch(Exception e){out.warning="历史查询失败："+e.getMessage();}
    }

    Models.Snapshot fetch(int id) throws Exception {
        JSONArray fixtures=get("/fixtures?id="+id).optJSONArray("response");
        if(fixtures==null||fixtures.length()==0)throw new IllegalStateException("未查询到比赛；请重新确认比赛ID");
        Models.Snapshot snapshot=new Models.Snapshot();
        JSONObject item=fixtures.getJSONObject(0);
        snapshot.fixture=parseFixture(item); snapshot.fetchedAt=System.currentTimeMillis();
        // Detailed fixture query may embed statistics/events: avoid redundant API calls.
        JSONArray stats=item.optJSONArray("statistics");
        if(stats==null)try{stats=get("/fixtures/statistics?fixture="+id).optJSONArray("response");}
        catch(Exception ignored){stats=null;}
        if(stats!=null)for(int i=0;i<stats.length();i++){
            JSONObject block=stats.optJSONObject(i);if(block==null)continue;
            JSONArray entries=block.optJSONArray("statistics");if(entries==null)continue;
            Models.Stat st=i==0?snapshot.home:snapshot.away;
            JSONObject team=block.optJSONObject("team");
            JSONObject baseTeams=item.optJSONObject("teams");
            if(team!=null&&baseTeams!=null&&baseTeams.optJSONObject("home")!=null){
                int homeId=baseTeams.getJSONObject("home").optInt("id",-1);
                st=team.optInt("id",-2)==homeId?snapshot.home:snapshot.away;
            }
            for(int j=0;j<entries.length();j++){
                JSONObject e=entries.optJSONObject(j);if(e==null)continue;
                Object v=e.opt("value"); if(v==null||v==JSONObject.NULL)continue;
                int num=-1;
                try{num=Integer.parseInt(String.valueOf(v).replace("%","").trim());}catch(Exception ignored){ }
                st.set(e.optString("type",""),num);
            }
        }
        JSONArray events=item.optJSONArray("events");
        if(events==null)try{events=get("/fixtures/events?fixture="+id).optJSONArray("response");}
        catch(Exception ignored){events=null;}
        StringBuilder b=new StringBuilder();
        if(events!=null)for(int i=0;i<events.length();i++){
            JSONObject e=events.optJSONObject(i);if(e==null)continue;
            String type=e.optString("type","");
            if(!"Goal".equals(type)&&!"Card".equals(type)&&!"Var".equals(type))continue;
            if("Goal".equals(type)&&e.optJSONObject("time")!=null){
                int goalAt=e.optJSONObject("time").optInt("elapsed",-1);
                if(goalAt>=0&&goalAt<=snapshot.fixture.minute){
                    snapshot.lastGoalMinute=Math.max(snapshot.lastGoalMinute,goalAt);
                }
            }
            JSONObject time=e.optJSONObject("time"),team=e.optJSONObject("team");
            b.append(time==null?"?":time.optInt("elapsed",-1)).append("' ")
             .append(team==null?"":team.optString("name","")).append(" ")
             .append(type).append(" ").append(e.optString("detail","")).append("\n");
        }
        snapshot.events=b.toString();
        return snapshot;
    }
}
